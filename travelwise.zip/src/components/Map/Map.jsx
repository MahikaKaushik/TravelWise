import React from 'react';
import { Paper, Typography, useMediaQuery } from '@material-ui/core';
import LocationOnOutlinedIcon from '@material-ui/icons/LocationOnOutlined';
import Rating from '@material-ui/lab/Rating';
import * as ReactBingmaps from 'react-bingmaps';

import useStyles from './styles';

const Map = ({ coords, places, setCoords, setBounds, setChildClicked, weatherData }) => {
  const matches = useMediaQuery('(min-width:600px)');
  const classes = useStyles();

  return (
    <div className={classes.mapContainer}>
      <ReactBingmaps.ReactBingmaps
        bingmapKey="YOUR_BING_MAPS_API_KEY"
        center={coords}
        zoom={14}
        className={classes.map}
      >
        {places.length &&
          places.map((place, i) => (
            <ReactBingmaps.Pushpin
              key={i}
              location={[Number(place.latitude), Number(place.longitude)]}
            >
              {!matches ? (
                <LocationOnOutlinedIcon color="primary" fontSize="large" />
              ) : (
                <Paper elevation={3} className={classes.paper}>
                  <Typography className={classes.typography} variant="subtitle2" gutterBottom>
                    {place.name}
                  </Typography>
                  <img
                    className={classes.pointer}
                    src={
                      place.photo
                        ? place.photo.images.large.url
                        : 'https://www.foodserviceandhospitality.com/wp-content/uploads/2016/09/Restaurant-Placeholder-001.jpg'
                    }
                    alt={place.name}
                  />
                  <Rating name="read-only" size="small" value={Number(place.rating)} readOnly />
                </Paper>
              )}
            </ReactBingmaps.Pushpin>
          ))}
        {weatherData?.list?.length &&
          weatherData.list.map((data, i) => (
            <ReactBingmaps.Pushpin
              key={i}
              location={[data.coord.lat, data.coord.lon]}
              option={{
                color: 'red',
              }}
            >
              <img
                src={`http://openweathermap.org/img/w/${data.weather[0].icon}.png`}
                height="70px"
                alt="Weather Icon"
              />
            </ReactBingmaps.Pushpin>
          ))}
      </ReactBingmaps.ReactBingmaps>
    </div>
  );
};

export default Map;
